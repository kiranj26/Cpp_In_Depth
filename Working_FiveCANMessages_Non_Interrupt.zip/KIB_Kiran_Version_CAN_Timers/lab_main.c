// lab_main.c
// Minimal scheduler; delegates all CAN specifics to kib_can module

#include "driverlib.h"
#include "device.h"
#include "board.h"
#include <stdbool.h>
#include "kib_can.h"

// task flags (ISRs set, main clears)
volatile bool due_10ms  = false;
volatile bool due_50ms  = false;
volatile bool due_200ms = false;

// LEDs from board.h
#define LED_HEARTBEAT  myBoardLED1_GPIO
#define LED_FAST       myBoardLED0_GPIO

static void Task_10ms(void);
static void Task_50ms(void);
static void Task_200ms(void);

int main(void)
{
    Device_init();
    Interrupt_initModule();
    Interrupt_initVectorTable();

    // keep your working divider
    SysCtl_setMCANClk(SYSCTL_MCANCLK_DIV_3);

    Board_init();

    // map dedicated TX buffers 0..4 to messages
    KibCanCfg cfg = {
        .mcan_base   = myMCAN0_BASE,
        .txbuf_0x710 = 0U,
        .txbuf_0x712 = 1U,
        .txbuf_0x713 = 2U,
        .txbuf_0x715 = 3U,
        .txbuf_0x716 = 4U,
        .endian      = CAN_ENDIAN_MOTOROLA
    };
    kib_can_init(&cfg);

    // enable the timers you actually use
    Interrupt_enable(INT_Timer_50ms);
    Interrupt_enable(INT_Timer_200ms);
    EINT; ERTM;

    for(;;){
        if(due_10ms)  { due_10ms  = false; Task_10ms();  }
        if(due_50ms)  { due_50ms  = false; Task_50ms();  }
        if(due_200ms) { due_200ms = false; Task_200ms(); }
        NOP;
    }
}

// ---------------- ISRs ----------------
__interrupt void INT_Timer_10ms_ISR(void){
    due_10ms = true;
    CPUTimer_clearOverflowFlag(Timer_10ms_BASE);
    Interrupt_clearACKGroup(INT_Timer_10ms_INTERRUPT_ACK_GROUP);
}
__interrupt void INT_Timer_50ms_ISR(void){
    due_50ms = true;
    CPUTimer_clearOverflowFlag(Timer_50ms_BASE);
}
__interrupt void INT_Timer_200ms_ISR(void){
    due_200ms = true;
    CPUTimer_clearOverflowFlag(Timer_200ms_BASE);
}

// ---------------- tasks ----------------
static void Task_10ms(void){
    // hook diagnostics if needed
}

static void Task_50ms(void){
    static uint8_t blink = 0;
    if (++blink >= 2) { GPIO_togglePin(LED_FAST); blink = 0; }
}

static void Task_200ms(void)
{
    GPIO_togglePin(LED_HEARTBEAT);

    KibCanState* s = kib_can_state();

    // 0x710 every 200 ms
    s->relay_cmd   = 1;
    kib_can_send_0x710();

    // 0x712/713/715/716 every 400 ms (every other tick)
    static bool half = false; half = !half;
    if (half){
        // fill demo values (replace with real measurements)
        s->relay_state = s->relay_cmd;

        s->temp1_C   = 23.45f;     // set to NAN to force SNA
        s->ambient_C = 24.10f;
        kib_can_send_0x712();

        s->l1_A = 12.5f; s->l2_A = 0.0f; s->n_A = 0.3f;
        kib_can_send_0x713();

        s->fw_day=31; s->fw_month=12; s->fw_year=2025;
        s->pcba_rev=4; s->pcba_loc=2; s->pcba_day=29; s->pcba_month=11; s->pcba_year=2025;
        s->pcba_buildnum=77; s->pcba_test_pass=1;
        kib_can_send_0x715();

        s->free_ram_bytes = 54321;
        kib_can_send_0x716();
    }
}
