// kib_can.c
#include "kib_can.h"
#include <string.h>
#include <math.h>

// Robust float-NaN check that doesn't require a library symbol:
#ifndef F_ISNANF
#define F_ISNANF(x) ((x) != (x))
#endif

// ---------------- module statics ----------------
static KibCanCfg   g_cfg;
static KibCanState g_state;

// FD+BRS, 8-byte payload (DLC=8). Change to DLC=15 if you go >8 in future.
static inline void mcan_tx_std8_from_buf(uint8_t bufIdx, uint16_t stdId, const uint8_t data[8])
{
    MCAN_TxBufElement el = {0};
    el.id  = ((uint32_t)stdId) << 18U;
    el.rtr = 0U; el.xtd = 0U; el.esi = 0U;
    el.fdf = 1U; el.brs = 1U;          // FD + BRS (matches your PCAN config)
    el.dlc = 8U;
    uint32_t i;
    for ( i=0;i<8;i++) el.data[i] = data[i];

    MCAN_writeMsgRam(g_cfg.mcan_base, MCAN_MEM_TYPE_BUF, bufIdx, &el);
    MCAN_txBufAddReq(g_cfg.mcan_base, bufIdx);
}

void kib_can_init(const KibCanCfg *cfg)
{
    g_cfg = *cfg;
    memset(&g_state, 0, sizeof(g_state));

    // sensible defaults
    g_state.temp1_C    = 25.f;
    g_state.ambient_C  = 25.f;
    g_state.relay_cmd  = 0U;
    g_state.relay_state= 0U;

    g_state.l1_A = 0.f;
    g_state.l2_A = 0.f;
    g_state.n_A  = 0.f;

    g_state.fw_day = 0; g_state.fw_month = 0; g_state.fw_year = 0; // year=0 -> SNA
    g_state.pcba_rev = 0; g_state.pcba_loc = 0;
    g_state.pcba_day = 0; g_state.pcba_month = 0; g_state.pcba_year = 0;
    g_state.pcba_buildnum = 0;
    g_state.pcba_test_pass= 0;

    g_state.free_ram_bytes = 0;
}

KibCanState* kib_can_state(void) { return &g_state; }

// ---------------- 0x710 ----------------
void kib_can_send_0x710(void)
{
    uint8_t p[8] = {0};
    pack_signal(p, RELAY_CMD_START, RELAY_CMD_LEN,
                (float)(g_state.relay_cmd ? 1 : 0), 1.0f, 0.0f, false, g_cfg.endian);
    mcan_tx_std8_from_buf(g_cfg.txbuf_0x710, ID_NFT_RELAY_COMMAND, p);
}

// ---------------- 0x712 ----------------
void kib_can_send_0x712(void)
{
    uint8_t p[8] = {0};
    if (F_ISNANF(g_state.temp1_C)) {
        can_pack_bits(p, TEMP1_START, TEMP1_LEN, SNA_S16, true, g_cfg.endian);
    } else {
        pack_signal(p, TEMP1_START, TEMP1_LEN, g_state.temp1_C, 0.01f, 0.0f, true, g_cfg.endian);
    }
    if (F_ISNANF(g_state.ambient_C)) {
        can_pack_bits(p, AMBIENT_START, AMBIENT_LEN, SNA_S16, true, g_cfg.endian);
    } else {
        pack_signal(p, AMBIENT_START, AMBIENT_LEN, g_state.ambient_C, 0.01f, 0.0f, true, g_cfg.endian);
    }
    pack_signal(p, RELAY_STATE_START, RELAY_STATE_LEN,
                (float)(g_state.relay_state ? 1 : 0), 1.0f, 0.0f, false, g_cfg.endian);

    mcan_tx_std8_from_buf(g_cfg.txbuf_0x712, ID_NFT_DATA_MEAS, p);
}

// ---------------- 0x713 ----------------
void kib_can_send_0x713(void)
{
    uint8_t p[8] = {0};
    if (F_ISNANF(g_state.l1_A)) {
        can_pack_bits(p, L1_CURR_START, L1_CURR_LEN, SNA_S16, true, g_cfg.endian);
    } else {
        pack_signal(p, L1_CURR_START, L1_CURR_LEN, g_state.l1_A, 0.00625f, 0.0f, true, g_cfg.endian);
    }
    if (F_ISNANF(g_state.l2_A)) {
        can_pack_bits(p, L2_CURR_START, L2_CURR_LEN, SNA_S16, true, g_cfg.endian);
    } else {
        pack_signal(p, L2_CURR_START, L2_CURR_LEN, g_state.l2_A, 0.00625f, 0.0f, true, g_cfg.endian);
    }
    if (F_ISNANF(g_state.n_A)) {
        can_pack_bits(p, N_CURR_START, N_CURR_LEN, SNA_S16, true, g_cfg.endian);
    } else {
        pack_signal(p, N_CURR_START, N_CURR_LEN, g_state.n_A, 0.00625f, 0.0f, true, g_cfg.endian);
    }

    mcan_tx_std8_from_buf(g_cfg.txbuf_0x713, ID_NFT_CURRENT_MEAS, p);
}

// ---------------- 0x715 ----------------
void kib_can_send_0x715(void)
{
    uint8_t p[8] = {0};

    // FW rev
    pack_signal(p, FW_REV_DD_START,   FW_REV_DD_LEN,   (float)g_state.fw_day,   1.0f, 0.0f, false, g_cfg.endian);
    pack_signal(p, FW_REV_MM_START,   FW_REV_MM_LEN,   (float)g_state.fw_month, 1.0f, 0.0f, false, g_cfg.endian);
    if (g_state.fw_year == 0) {
        can_pack_bits(p, FW_REV_YYYY_START, FW_REV_YYYY_LEN, SNA_U7, false, g_cfg.endian);
    } else {
        pack_signal(p, FW_REV_YYYY_START, FW_REV_YYYY_LEN, (float)(g_state.fw_year - FW_REV_YYYY_OFF), 1.0f, 0.0f, false, g_cfg.endian);
    }

    // PCBA fields
    uint32_t pcba_rev_raw = (g_state.pcba_rev > 30) ? 30 : g_state.pcba_rev;
    pack_signal(p, PCBA_REV_START, PCBA_REV_LEN, (float)pcba_rev_raw, 1.0f, 0.0f, false, g_cfg.endian);
    pack_signal(p, PCBA_LOC_START, PCBA_LOC_LEN, (float)g_state.pcba_loc, 1.0f, 0.0f, false, g_cfg.endian);
    pack_signal(p, PCBA_DD_START,  PCBA_DD_LEN,  (float)g_state.pcba_day, 1.0f, 0.0f, false, g_cfg.endian);
    pack_signal(p, PCBA_MM_START,  PCBA_MM_LEN,  (float)g_state.pcba_month, 1.0f, 0.0f, false, g_cfg.endian);

    if (g_state.pcba_year == 0) {
        can_pack_bits(p, PCBA_YYYY_START, PCBA_YYYY_LEN, SNA_U7, false, g_cfg.endian);
    } else {
        pack_signal(p, PCBA_YYYY_START, PCBA_YYYY_LEN, (float)(g_state.pcba_year - PCBA_YYYY_OFF), 1.0f, 0.0f, false, g_cfg.endian);
    }

    if (g_state.pcba_buildnum > 4095) {
        can_pack_bits(p, PCBA_BUILDNUM_START, PCBA_BUILDNUM_LEN, SNA_U12, false, g_cfg.endian);
    } else {
        pack_signal(p, PCBA_BUILDNUM_START, PCBA_BUILDNUM_LEN, (float)g_state.pcba_buildnum, 1.0f, 0.0f, false, g_cfg.endian);
    }

    pack_signal(p, PCBA_TEST_STATUS_START, PCBA_TEST_STATUS_LEN, (float)(g_state.pcba_test_pass ? 1 : 0), 1.0f, 0.0f, false, g_cfg.endian);

    mcan_tx_std8_from_buf(g_cfg.txbuf_0x715, ID_KIB_HW_FW, p);
}

// ---------------- 0x716 ----------------
void kib_can_send_0x716(void)
{
    uint8_t p[8] = {0};
    if (g_state.free_ram_bytes > 70000u) {
        can_pack_bits(p, FREE_RAM_START, FREE_RAM_LEN, SNA_U17, false, g_cfg.endian);
    } else {
        pack_signal(p, FREE_RAM_START, FREE_RAM_LEN, (float)g_state.free_ram_bytes, 1.0f, 0.0f, false, g_cfg.endian);
    }
    mcan_tx_std8_from_buf(g_cfg.txbuf_0x716, ID_DEBUG_DATA, p);
}
