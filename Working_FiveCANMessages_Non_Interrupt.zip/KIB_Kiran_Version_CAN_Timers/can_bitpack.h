// can_bitpack.h
#pragma once
#include <stdint.h>
#include <stdbool.h>


typedef enum { CAN_ENDIAN_MOTOROLA = 0, CAN_ENDIAN_INTEL = 1 } CanEndian;

static inline uint64_t clamp_signed_to_bits(int64_t v, uint8_t bits){
    int64_t mn = -(1LL << (bits-1));
    int64_t mx =  (1LL << (bits-1)) - 1;
    if (v < mn) v = mn;
    if (v > mx) v = mx;
    return (uint64_t)(v & ((1ULL<<bits)-1));
}
static inline uint64_t clamp_unsigned_to_bits(uint64_t v, uint8_t bits){
    uint64_t mx = (bits==64) ? ~0ULL : ((1ULL<<bits)-1);
    if (v > mx) v = mx;
    return v;
}

// Pack raw bits into bytes[0..7] at [startBit, length]
static inline void can_pack_bits(uint8_t bytes[8], uint32_t startBit, uint8_t length,
                                 uint64_t raw, bool isSigned, CanEndian endian)
{
    (void)isSigned;
    if (endian == CAN_ENDIAN_INTEL){
        uint8_t i;
        for ( i=0;i<length;i++){
            uint32_t bp = startBit + i;
            uint32_t by = bp / 8U;
            uint8_t  bi = bp % 8U;
            if (by >= 8U) continue;
            uint8_t bit = (raw >> i) & 1U;
            bytes[by] = (uint8_t)((bytes[by] & ~(1U<<bi)) | (bit<<bi));
        }
    } else {
        uint8_t i;
        for ( i=0;i<length;i++){
            uint32_t mb = startBit + i;
            uint32_t by = mb / 8U;
            uint8_t  ms = 7U - (mb % 8U);
            if (by >= 8U) continue;
            uint8_t bit = (raw >> (length-1 - i)) & 1U;
            bytes[by] = (uint8_t)((bytes[by] & ~(1U<<ms)) | (bit<<ms));
        }
    }
}

static inline void pack_signal(uint8_t bytes[8], uint32_t startBit, uint8_t length,
                               float phys, float factor, float offset,
                               bool isSigned, CanEndian endian)
{
    float rd = (phys - offset) / factor;
    int64_t ri = (int64_t)((rd >= 0.0f) ? (rd + 0.5f) : (rd - 0.5f));
    uint64_t ru = isSigned ? clamp_signed_to_bits(ri, length)
                           : clamp_unsigned_to_bits((uint64_t)ri, length);
    can_pack_bits(bytes, startBit, length, ru, isSigned, endian);
}
