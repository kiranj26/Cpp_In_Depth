// kib_can.h
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "driverlib.h"
#include "can_bitpack.h"

#ifdef __cplusplus
extern "C" {
#endif

// -------------------- Arbitration IDs --------------------
#define ID_NFT_RELAY_COMMAND   0x710
#define ID_NFT_ERROR_FLAGS     0x711   // placeholder (not encoded yet)
#define ID_NFT_DATA_MEAS       0x712
#define ID_NFT_CURRENT_MEAS    0x713
#define ID_UPS_DATA            0x714   // placeholder (not encoded yet)
#define ID_KIB_HW_FW           0x715
#define ID_DEBUG_DATA          0x716

// -------------------- Bit layouts per your sheet --------------------
// 0x710
#define RELAY_CMD_START   0
#define RELAY_CMD_LEN     1

// 0x712 (signed16 @ 0.01 °C, SNA=0x7FFF)
#define TEMP1_START       0
#define TEMP1_LEN         16
#define AMBIENT_START     16
#define AMBIENT_LEN       16
#define RELAY_STATE_START 32
#define RELAY_STATE_LEN   1
#define SNA_S16           0x7FFFu

// 0x713 (signed16 @ 0.00625 A, SNA=0x7FFF)
#define L1_CURR_START     0
#define L1_CURR_LEN       16
#define L2_CURR_START     16
#define L2_CURR_LEN       16
#define N_CURR_START      32
#define N_CURR_LEN        16

// 0x715 (all unsigned; years have offset 2000 and SNA=0x7F)
#define FW_REV_DD_START    0   // u5
#define FW_REV_DD_LEN      5
#define FW_REV_MM_START    5   // u4
#define FW_REV_MM_LEN      4
#define FW_REV_YYYY_START  9   // u7 (offset 2000)
#define FW_REV_YYYY_LEN    7
#define FW_REV_YYYY_OFF  2000
#define SNA_U7            0x7Fu

#define PCBA_REV_START    16   // u5, SNA=0x1F
#define PCBA_REV_LEN       5
#define SNA_U5            0x1Fu

#define PCBA_LOC_START    21   // u4
#define PCBA_LOC_LEN       4
#define PCBA_DD_START     25   // u5
#define PCBA_DD_LEN        5
#define PCBA_MM_START     30   // u4
#define PCBA_MM_LEN        4
#define PCBA_YYYY_START   34   // u7 (offset 2000)
#define PCBA_YYYY_LEN      7
#define PCBA_YYYY_OFF    2000
#define PCBA_BUILDNUM_START 41 // u12, SNA=0xFFF
#define PCBA_BUILDNUM_LEN   12
#define SNA_U12           0xFFFu
#define PCBA_TEST_STATUS_START 53 // u1
#define PCBA_TEST_STATUS_LEN   1

// 0x716 (u17, 0..70000 Bytes, SNA=0x1FFFF)
#define FREE_RAM_START     0
#define FREE_RAM_LEN       17
#define SNA_U17            0x1FFFFu

// -------------------- Config & State --------------------
typedef struct {
    uint32_t mcan_base;     // e.g. myMCAN0_BASE
    // dedicated TX buffer indices (MsgRAM must have size >= 5)
    uint8_t  txbuf_0x710;
    uint8_t  txbuf_0x712;
    uint8_t  txbuf_0x713;
    uint8_t  txbuf_0x715;
    uint8_t  txbuf_0x716;
    CanEndian endian;       // MOTOROLA vs INTEL (your sheet looks Motorola)
} KibCanCfg;

typedef struct {
    // 0x710
    uint8_t  relay_cmd;        // 0/1
    // 0x712
    float    temp1_C;          // NaN -> SNA 0x7FFF
    float    ambient_C;        // NaN -> SNA 0x7FFF
    uint8_t  relay_state;      // 0/1
    // 0x713
    float    l1_A;             // NaN -> SNA 0x7FFF
    float    l2_A;             // NaN -> SNA 0x7FFF
    float    n_A;              // NaN -> SNA 0x7FFF
    // 0x715
    uint8_t  fw_day;           // 1..31 (0 if unknown -> year SNA means ignore date)
    uint8_t  fw_month;         // 1..12
    uint16_t fw_year;          // 2000..2126 (0 -> SNA)
    uint8_t  pcba_rev;         // 0..30   (31 -> SNA 0x1F)
    uint8_t  pcba_loc;         // 0..14
    uint8_t  pcba_day;         // 1..31
    uint8_t  pcba_month;       // 1..12
    uint16_t pcba_year;        // 2000..2126 (0 -> SNA)
    uint16_t pcba_buildnum;    // 0..4095 (4095 -> SNA 0xFFF)
    uint8_t  pcba_test_pass;   // 0/1
    // 0x716
    uint32_t free_ram_bytes;   // 0..70000 (>=70001 -> SNA)
} KibCanState;

// -------------------- API --------------------
void kib_can_init(const KibCanCfg *cfg);
KibCanState* kib_can_state(void);

// one-shot senders (you decide the scheduling in your tasks)
void kib_can_send_0x710(void);
void kib_can_send_0x712(void);
void kib_can_send_0x713(void);
void kib_can_send_0x715(void);
void kib_can_send_0x716(void);

#ifdef __cplusplus
}
#endif
